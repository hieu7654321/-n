package dev.hieu.mcenterproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MCenterProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
