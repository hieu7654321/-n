package dev.hieu.mcenterproject.Eum;

public enum UsersRole {
    STUDENT,
    TEACHER,
    ADMIN;
}
